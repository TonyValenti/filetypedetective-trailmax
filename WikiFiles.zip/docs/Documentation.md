**List of all available functions will be included in API documentation in release archive available for download**

Project is a library of functions. Download the FileTypeDetective.dll from download section and add it to your Visual Studio project as a reference: right click on **Project Name -> Add Reference -> Browse** and point this to the downloaded file. For more details check MSDN guide: [http://msdn.microsoft.com/en-us/library/wkze6zky%28v=vs.80%29.aspx](http://msdn.microsoft.com/en-us/library/wkze6zky%28v=vs.80%29.aspx)

Then in every class where you need to use FileDetective add reference to the library:
{{
using FileTypeDetective;
}}

This will provide a list of extension functions for FileInfo objects.
The usage is as following:
{{
FileInfo file = new FileInfo("C:\tmp\unknown.file");

// returns file type - one of the contants defined in the class
FileType type = file.GetFileType();

// writes the file extension
Console.WriteLine(type.ToString());

// compares if the file belongs to some type
if (type.isType(FileTypeDetective.WORD))
{
   Console.WriteLine("File is MS Word");
}

// returns true if the file is PDF
if (type.isPdf()){
   Console.WriteLine("Pdf");
}
}}
